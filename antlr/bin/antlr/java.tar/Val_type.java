package antlr;

enum Val_type {
	t_void, t_char, t_int, t_float, t_double
}

