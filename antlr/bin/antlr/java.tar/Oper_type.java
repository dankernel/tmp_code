package antlr;



public enum Oper_type {

	/* add.. */
	declaration, equal, _if, _for, _while

}