package antlr;

/* 가상 클레스 */
public class V_argument {

}
